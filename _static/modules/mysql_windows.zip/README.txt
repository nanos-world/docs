Place mysql.dll into Modules/luasql
Place libmysql.dll into the same folder as NanosWorldServer.exe