Place mysql.dll into Modules/luasql
Place libmysql.dll into the same folder as NanosWorldServer.exe
Place libssl-1_1-x64.dll into the same folder as NanosWorldServer.exe
Place libcrypto-1_1-x64.dll into the same folder as NanosWorldServer.exe