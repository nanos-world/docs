Place mysql.so into Modules/luasql
Install libmysqlclient on your server